﻿ALTER USER pruebasql;

DROP DATABASE if exists  mardones_daniel_guerrero_jorge;
CREATE DATABASE mardones_daniel_guerrero_jorge;